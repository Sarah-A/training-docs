﻿using NUnit.Framework;

namespace ExercisesTests
{
    [TestFixture]
    public class Select_QuerySyntax_Exercise2_Tests
    {
    }
}
