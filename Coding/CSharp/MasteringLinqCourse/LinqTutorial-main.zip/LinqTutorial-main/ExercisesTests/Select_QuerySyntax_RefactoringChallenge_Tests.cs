﻿using NUnit.Framework;

namespace ExercisesTests
{
    [TestFixture]
    public class Select_QuerySyntax_RefactoringChallenge_Tests
    {
    }
}
