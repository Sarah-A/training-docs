﻿namespace LinqTutorial.DataTypes
{
    public enum PetType
    {
        Cat,
        Dog,
        Fish
    }
}
