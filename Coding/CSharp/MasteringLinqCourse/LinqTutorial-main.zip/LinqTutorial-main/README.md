# LinqTutorial

Hello! 

My name is Krystyna and welcome to my GitHub.

This repository is part of my  "LINQ Tutorial: Master the Key C# Library" course, which you can find under this link: https://www.udemy.com/course/linq-tutorial-master-the-key-csharp-library/?referralCode=384B340D233F12F6A498

## FAQ:

### Q1: How do I download the files?
A: If you're not familiar with GitHub and just want to download the entire solution, click the green button saying "Code", and then select the "Download ZIP".
